import json

def fill_events(json_text_dat, output_table_dat):
    """Text DAT JSON -> Table DAT de eventos, sin dependencias externas."""
    data = json.loads(json_text_dat.text)
    fields = ['id', 'time', 'scene', 'place', 'action', 'resource', 'lot', 'relation', 'causedBy']
    output_table_dat.clear()
    output_table_dat.appendRow(fields)
    for event in data.get('events', []):
        output_table_dat.appendRow([event.get(field, '') for field in fields])
