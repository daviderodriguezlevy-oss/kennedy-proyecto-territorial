def frame_rows(table, scene, scenario, time_s):
    """Table DAT -> filas del instante más próximo (10 Hz)."""
    header = [cell.val for cell in table.row(0)]
    target = round(float(time_s) * 10) / 10
    result = []
    for row in table.rows()[1:]:
        item = dict(zip(header, [cell.val for cell in row]))
        if (int(item['scene']) == scene and item['scenario'] == scenario
                and abs(float(item['time_s']) - target) < 0.001):
            result.append(item)
    return result
